<?php
class ViewFooter {
    public function displayView(): string{
        return "footer>
          <p></p>
        </footer>
        </body>
        </html>
      ";
    }
    
}