<?php

class ViewHome{
  private ?string $message = '';
  private ?string $GamerLister = '';

  public function getMessage(): ?string {
    return $this->message;
  }

  public function setMessage(?string $newMessage): self {
    $this->message = $newMessage;
    return $this;
  }

  public function getGamerLister(): ?string {
    return $this->GamerLister;
  }

  public function setGamerLister(?string $newGamerLister): self {
    $this->GamerLister = $newGamerLister;
    return $this;
  }

  //METHOD
  public function displayView(): string {
    return "
        <main>
            <section>
            <h2>Nouveau Joueur</h2>
            <form action='' method='post'>
                <label for='pseudo'>Pseudo</label><br />
                <input type='text' name='pseudo' required><br /><br/>
                <label for='email'>email</label><br />
                <input type='text' name='email' required /><br /><br />

                <label for='password'>Mot de Passe</label><br />
                <input type='password' name='password' required /><br /><br />

                <label for='score'>Score</label><br />
                <input type='number' name='score' id='score' required /><br /><br />

                <input type='submit' name='submit' value='Envoyer' required /><br />
                <p>" . $this->getMessage() . "</p>

            </form>
            </section>
            <section>
            <h1>Liste des joueurs</h1>
              <ul>
              " . $this->getGamerLister() . "
              </ul>
            </section>
        </main>
    ";
  }
}