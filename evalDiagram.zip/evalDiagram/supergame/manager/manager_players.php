<?php
include './utils/utils.php';
include './model/model_players.php';
include '.view/view_home.php';
include '.view/header.php';
include '.view/footer.php';

class ManagerPlayers {
  private ?ViewHome $viewHome;
  private ?ModelJoueurs $modelPlayer;
  private ?ViewHeader $viewHeader;
  private ?ViewFooter $viewFooter;

  public function getViewHeader(): ?ViewHeader{
    return $this->viewHeader;
  }

  public function setViewHeader(?ViewHeader $viewHeader): self {
    $this->viewHeader = $viewHeader;
    return $this;
  }

  public function getViewFooter(): ?ViewFooter {
    return $this->viewFooter;
  }

  public function setViewFooter(?ViewFooter $viewFooter): self {
    $this->viewFooter = $viewFooter;
    return $this;
  }

  public function getViewHome(): ?ViewHome {
    return $this->viewHome;
  }

  public function setViewHome(?ViewHome $viewHome): self
  {
    $this->viewHome = $viewHome;
    return $this;
  }

  public function getModelPlayer(): ?ModelJoueurs {
    return $this->modelPlayer;
  }

  public function setModelPlayer(?ModelJoueurs $modelPlayer): self {
    $this->modelPlayer = $modelPlayer;
    return $this;
  }
    
  public function sincrire(): string {
    if (isset($_POST['submit'])) {
      if (isset($_POST['pseudo']) && !empty($_POST['pseudo'])
        && isset($_POST['email']) && !empty($_POST['email'])
        && isset($_POST['score']) && !empty($_POST['score'])
        && isset($_POST['password']) && !empty($_POST['password'])) {
        if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
          $pseudo = sanitize($_POST['pseudo']);
          $email = sanitize($_POST['email']);
          $score = sanitize($_POST['score']);
          $password = sanitize($_POST['password']);
          $password = password_hash($password, PASSWORD_BCRYPT);

          
          try {
            $data = $this->getModelPlayer()->setEmail($email)->getPlayerByMail();


            if (empty($data)) {
              $this->getModelPlayer()->setPseudo($pseudo)->setEmail($email)->setPassword($password)->setScore($score);

              $this->getViewHome()->setMessage($this->getModelPlayer()->addPlayer());

              return "$pseudo a été enregistré en BDD.";

            } else {
              return "Cet adresse mail existe déjà sur un autre compte.";
            }

          } catch (EXCEPTION $error) {
            return $error->getMessage();
          }

        } else {
          return "Le mail n'est pas au bon format !";
        }

      } else {
        return "Veuillez remplir les champs.";
      }
    }
    return '';
  }
  
  public function gamerLister(): string {
    $gamerLister = '';
    $data = $this->getModelPlayer()->getPlayers();

    foreach ($data as $gamer) {
      $gamerLister = $gamerLister . "
      <li>
        <h2>Joueur: {$gamer['pseudo']}</h2>
        <p>email: {$gamer['email']}<p>
        <p>Score: {$gamer['score']}<p>
      </li>";
    }
    return $gamerLister;
  }

  public function render(): void {
    echo $this->setViewHeader(new ViewHeader)->getViewHeader()->displayView();

    echo $this->getViewHome()->setMessage($this->sincrire())->setGamerLister($this->gamerLister())->displayView();

    echo $this->setViewFooter(new ViewFooter)->getViewFooter()->displayView();
  }
}

$home = new ManagerPlayers(new ViewHome, new ModelJoueurs);
$home->render();
