<main>
    <section>
        <h1>Inscription</h1>
        <form action="" method="POST">
            <input type="text" name="nickname" placeholder="Votre Pseudo" />
            <input type="text" name="email" placeholder="Votre Email" />
            <input type="text" name="password" placeholder="Votre Mot de Passe" />
            <input type="text" name="password" placeholder="Votre Mot de Passe" />
            <input type="submit" name="submit"/>
        </form>
    </section>        
</main>